//
//  AppDelegate.h
//  HActiveManger
//
//  Created by 白仕云 on 2018/10/25.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

