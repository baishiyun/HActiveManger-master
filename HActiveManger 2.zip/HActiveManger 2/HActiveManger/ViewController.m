//
//  ViewController.m
//  HActiveManger
//
//  Created by 白仕云 on 2018/10/25.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import "ViewController.h"
#import "HActiveManger/HActiveHeader.h"


static NSString *const HActiveMangerID = @"HActiveManger";
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self creatHActiveManger];

}


-(void)creatUIs{


    UICollectionViewFlowLayout *layput  =[[UICollectionViewFlowLayout alloc]init];
    layput.itemSize = CGSizeMake(self.view.frame.size.width/2.0, self.view.frame.size.height/2.0);
    layput.minimumLineSpacing = 0;
    layput.minimumInteritemSpacing = 0;


    HActiveCollectionView *tableView = [[HActiveCollectionView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) collectionViewLayout:layput];
    [self .view addSubview:tableView];

    NSMutableArray *array = [NSMutableArray array];

    for (int index=0; index<10; index++) {
        [array addObject:[NSString stringWithFormat:@"index=%d",index]];
    }
    tableView.dataArray  =array;
    [tableView setGetCell_HActiveTableView:^(HActiveCollectionViewCell * _Nonnull cell, NSIndexPath * _Nonnull cellIndexPath) {

        CGRect rect  =CGRectMake(0, 0, layput.itemSize.width, layput.itemSize.height);

        UIView *view  =[[UIView alloc]initWithFrame:rect];
        view.backgroundColor = [UIColor colorWithRed:(cellIndexPath.row*7.5)/255.0 green:(cellIndexPath.row*3+150)/255.0 blue:(cellIndexPath.row*2+100)/255.0 alpha:1];
        [cell addSubview:view];

    }];

    [tableView setDidSelectRowCell_HActiveTableView:^(HActiveCollectionViewCell * _Nonnull cell, NSIndexPath * _Nonnull cellIndexPath) {

        NSLog(@"   %d",cellIndexPath.row);
    }];





    //    HActiveTableView *tableView = [[HActiveTableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    //    [self .view addSubview:tableView];
    //
    //    tableView.dataArray  =[NSMutableArray arrayWithObjects:@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",@"ewew",@"ewew" ,@"ewew",nil];
    //    [tableView setGetCell_HActiveTableView:^(UITableViewCell * _Nonnull cell, NSIndexPath * _Nonnull cellIndexPath) {
    //        CGRect rect  =CGRectMake(0, 0, self.view.frame.size.width, 100.0);
    //        if (cellIndexPath.row==0) {
    //            UIView *view  =[[UIView alloc]initWithFrame:rect];
    //            view.backgroundColor = [UIColor redColor];
    //            [cell addSubview:view];
    //        }else if(cellIndexPath.row==1){
    //            UIView *view  =[[UIView alloc]initWithFrame:rect];
    //            view.backgroundColor = [UIColor blueColor];
    //            [cell addSubview:view];
    //        }else if (cellIndexPath.row==2){
    //            UIView *view  =[[UIView alloc]initWithFrame:rect];
    //            view.backgroundColor = [UIColor yellowColor];
    //            [cell addSubview:view];
    //        }
    //    }];
    //
    //    [tableView setDidSelectRowCell_HActiveTableView:^(UITableViewCell * _Nonnull cell, NSIndexPath * _Nonnull cellIndexPath) {
    //
    //
    //    }];
}


/**
 数据存储功能
 */
-(void)creatHActiveManger
{

    [HActiveManger deletedAllKey:HActiveMangerID Complete:^(BOOL complete, NSMutableArray * _Nonnull completeArray) {

        NSLog(@"   %d   %@",complete,completeArray);

    }];

    CGSize Manin = [UIScreen mainScreen].bounds.size;

    UIButton * creatHActiveManger = [self reutnBtnWithTitleString:@"开始保存数据" frame:CGRectMake((Manin.width-100)/2.0, 100, 100, 30) btnTag:100];
    [self.view addSubview:creatHActiveManger];


    UIButton * addHActiveManger = [self reutnBtnWithTitleString:@"增加保存数据" frame:CGRectMake((Manin.width-100)/2.0, 200, 100, 30) btnTag:200];
    [self.view addSubview:addHActiveManger];


    UIButton * updateHActiveManger = [self reutnBtnWithTitleString:@"更新数据" frame:CGRectMake((Manin.width-100)/2.0, 300, 100, 30) btnTag:300];
    [self.view addSubview:updateHActiveManger];


    UIButton * deletedHActiveManger = [self reutnBtnWithTitleString:@"删除保存数据" frame:CGRectMake((Manin.width-100)/2.0, 400, 100, 30) btnTag:400];
    [self.view addSubview:deletedHActiveManger];

}


-(void)btnClcik:(UIButton *)btn
{

    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setObject:@"小白" forKey:@"name"];
    [dict setObject:@"28" forKey:@"age"];


    NSMutableArray *array  =[NSMutableArray array];
    [array addObject:dict];
    switch (btn.tag) {
        case 100:
            [HActiveManger saveParameter:@"rrrr" Key:HActiveMangerID Complete:^(BOOL complete,NSMutableArray *completeArray) {

                NSLog(@"   %d   %@",complete,completeArray);

            }];
            break;

        case 200:
            [HActiveManger addSaveParameter:array Key:HActiveMangerID Complete:^(BOOL complete,NSMutableArray *completeArray) {

                NSLog(@"   %d   %@",complete,completeArray);

            }];
            break;

        case 300:
            [HActiveManger updateMajorValue:@"王小明" Key:HActiveMangerID majorkey:@"name" Complete:^(BOOL complete,NSMutableArray *completeArray) {

                NSLog(@"   %d   %@",complete,completeArray);

            }];
            break;

        case 400:

            [HActiveManger deletedMajorkey:@"age" MajorValue:@"28" Key:HActiveMangerID Complete:^(BOOL complete,NSMutableArray *completeArray) {
                        NSLog(@"   %d   %@",complete,completeArray);

            }];

            break;

        default:
            break;
    }
}


-(UIButton *)reutnBtnWithTitleString:(NSString *)titleString frame:(CGRect)frame btnTag:(int)btnTag

{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame  =frame;
    [btn setTitle:titleString forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btn.tag =btnTag;
    [btn addTarget:self action:@selector(btnClcik:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

@end

